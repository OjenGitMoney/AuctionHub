<?php 
$dbname="auction";
$username="db2admin";
$password="cs174";
$computerName = "OWNER";
    ?>